package com.insertmask.initial.model;

import org.springframework.data.repository.CrudRepository;

public interface IResearchedTechnologies extends CrudRepository<ResearchedTechnologies, Integer>{

}
