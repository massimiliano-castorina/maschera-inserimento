package com.insertmask.initial.model;

import org.springframework.data.repository.CrudRepository;

public interface IRegistration extends CrudRepository<Registration,Integer>{

}
