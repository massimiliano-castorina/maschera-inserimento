package com.insertmask.initial.model;

import org.springframework.data.repository.CrudRepository;

public interface IReferents extends CrudRepository<Referents, Integer>{

}
