package com.insertmask.initial.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.insertmask.initial.model.*;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class Controller {

	@Autowired
	IReferents ref;
	
	@Autowired
	IRegistration reg;
	
	@Autowired
	IResearchedTechnologies resTeck;
	
	int lastIdRef;
	int lastIdResTeck;
	
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/registration")
	@ResponseBody
	//public void insertNewRegistration(@RequestBody Registration rg, Referents rf, ResearchedTechnologies rt) {
	//public void insertNewRegistration(@RequestBody Registration rg, @RequestBody Registration rg, @RequestBody Registration rg) {
	public void insertNewRegistration(@RequestBody Registration rg) {
		
		//System.out.println(mc.rt.getNameresearchedtechnlogies());
		System.out.println("sono qui");
		lastIdRef = 1;
		lastIdResTeck = 1;
//		Registration registration = new Registration();
//		Referents referents = new Referents();
//		ResearchedTechnologies researchedTechnologies = new ResearchedTechnologies();
		

		
		
		
		ref.findAll().forEach(searchRf -> {
			//lastIdRef = searchRf.getId()+1;
			lastIdRef = (int) ref.count()+1;
		});
		
		resTeck.findAll().forEach(searchRf -> {
			//lastIdResTeck = searchRf.getId()+1;
			lastIdResTeck = (int) ref.count()+1;
		});
		
//		registration.setOffice(mc.rg.getOffice());
//		registration.setCustomer(mc.rg.getCustomer());
//		referents.setId(lastIdRef);
//		referents.setNamereferents(mc.rf.getNamereferents());
//		researchedTechnologies.setId(lastIdResTeck);
//		researchedTechnologies.setNameresearchedtechnlogies(mc.rt.getNameresearchedtechnlogies());
		
		//System.out.println("sono qui");
//		registration.setIdReferents(lastIdRef);
//		registration.setIdResearchTechnologies(lastIdResTeck);
		
//		ref.save(referents);
//		resTeck.save(researchedTechnologies);
//		reg.save(registration);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/registration")
	@ResponseBody
	//public void insertNewRegistration(@RequestBody Registration rg, Referents rf, ResearchedTechnologies rt) {
	//public void insertNewRegistration(@RequestBody Registration rg, @RequestBody Registration rg, @RequestBody Registration rg) {
	public void insertNewRegistration(@RequestBody Referents re ) {
		
		//System.out.println(mc.rt.getNameresearchedtechnlogies());
		System.out.println("sono qui");
		lastIdRef = 1;
		lastIdResTeck = 1;
//		Registration registration = new Registration();
//		Referents referents = new Referents();
//		ResearchedTechnologies researchedTechnologies = new ResearchedTechnologies();
		

		
		
//		
//		ref.findAll().forEach(searchRf -> {
//			//lastIdRef = searchRf.getId()+1;
//			lastIdRef = (int) ref.count()+1;
//		});
//		
//		resTeck.findAll().forEach(searchRf -> {
//			//lastIdResTeck = searchRf.getId()+1;
//			lastIdResTeck = (int) ref.count()+1;
//		});
		
//		registration.setOffice(mc.rg.getOffice());
//		registration.setCustomer(mc.rg.getCustomer());
//		referents.setId(lastIdRef);
//		referents.setNamereferents(mc.rf.getNamereferents());
//		researchedTechnologies.setId(lastIdResTeck);
//		researchedTechnologies.setNameresearchedtechnlogies(mc.rt.getNameresearchedtechnlogies());
		
		//System.out.println("sono qui");
//		registration.setIdReferents(lastIdRef);
//		registration.setIdResearchTechnologies(lastIdResTeck);
		
//		ref.save(referents);
//		resTeck.save(researchedTechnologies);
//		reg.save(registration);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/aaaa")
	@ResponseBody
	//public void insertNewRegistration(@RequestBody Registration rg, Referents rf, ResearchedTechnologies rt) {
	//public void insertNewRegistration(@RequestBody Registration rg, @RequestBody Registration rg, @RequestBody Registration rg) {
	public void insertNewRegistration(@RequestBody ResearchedTechnologies rt) {
		
		//System.out.println(mc.rt.getNameresearchedtechnlogies());
		System.out.println("sono qui");
		lastIdRef = 1;
		lastIdResTeck = 1;
//		Registration registration = new Registration();
//		Referents referents = new Referents();
//		ResearchedTechnologies researchedTechnologies = new ResearchedTechnologies();
		

		
		
		
//		ref.findAll().forEach(searchRf -> {
//			//lastIdRef = searchRf.getId()+1;
//			lastIdRef = (int) ref.count()+1;
//		});
//		
//		resTeck.findAll().forEach(searchRf -> {
//			//lastIdResTeck = searchRf.getId()+1;
//			lastIdResTeck = (int) ref.count()+1;
//		});
		
//		registration.setOffice(mc.rg.getOffice());
//		registration.setCustomer(mc.rg.getCustomer());
//		referents.setId(lastIdRef);
//		referents.setNamereferents(mc.rf.getNamereferents());
//		researchedTechnologies.setId(lastIdResTeck);
//		researchedTechnologies.setNameresearchedtechnlogies(mc.rt.getNameresearchedtechnlogies());
		
		//System.out.println("sono qui");
//		registration.setIdReferents(lastIdRef);
//		registration.setIdResearchTechnologies(lastIdResTeck);
		
//		ref.save(referents);
//		resTeck.save(researchedTechnologies);
//		reg.save(registration);
	}
	
}
