package com.insertmask.initial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
